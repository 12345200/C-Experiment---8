/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<iostream>
using namespace std;

class First {
public:

   virtual void calculate() {
       cout << "Arithmetic calculation";
   }
};

class Second : public First {
public:

   int p, q, result;
   int ch;

   void calculate() {

       cout << "1. Addition :";
       cout << "\n2.Subtraction :";
       cout << "\n3.Multiplication :";
       cout << "\n4.Division :";
       cout << "\n5.Mode :\n";
       cin >> ch;

       switch (ch) {
           case 1:
           {
               cout << "\nEnter Two Numbers :";
               cin >> p>>q;
               res = p+q;
               cout << "\nResult is :" << result;
               break;
           }
           case 2:
           {
               cout << "\nEnter Two Numbers :";
               cin >>p>>  q;
               res = p - q;
               cout << "\nResult is :" << result;
               break;
           }
           case 3:
           {
               cout << "\nEnter Two Numbers :";
               cin >> p>>  q;
               res = p * q;
               cout << "\nResult is :" << result;
               break;
           }
           case 4:
           {
               cout << "\nEnter Two Numbers :";
               cin >> p >> q;
               res = p / q;
               cout << "\nResult is :" << result;
               break;
           }
           case 5:
           {
               cout << "\nEnter Two Numbers :";
               cin >> p >> q;
               res = p % q;
               cout << "\nResult is :" << result;
               break;
           }
           default:
           cout<<"\nEnter valid selection";
       }
   }
};

int main() {

   First *F;
   Second S;
   F = &S;
   F->calculate();
   return 0;
}